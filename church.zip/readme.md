# Sistema de adminitración de partidas
Lleva el control de las partidas de bautismos, confirmación y matrimonio de una parroquia.