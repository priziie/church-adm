<template>
    <h1>Bienvenido/a</h1>
</template>
